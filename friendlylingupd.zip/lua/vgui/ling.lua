net.Receive("message_ling_hi", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "Hi!")
chat.PlaySound()
    end)

net.Receive("message_ling_bye", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "Bye!")
chat.PlaySound()
    end)

net.Receive("message_ling_cong", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "Congratulations!")
chat.PlaySound()
    end)

net.Receive("message_ling_hide", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "I'm hiding, find me in 4 minutes.")
chat.PlaySound()
    end)

net.Receive("message_ling_seek", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "I'm seeking, hide in 1 minute.")
chat.PlaySound()
    end)

net.Receive("message_ling_seek2", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "Ready or not, here I come! Stay hiding in 2 minutes.")
chat.PlaySound()
    end)

net.Receive("message_ling_hideend", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "You don't find me!")
chat.PlaySound()
    end)

net.Receive("message_ling_seekend", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "I found you!")
chat.PlaySound()
    end)

net.Receive("message_ling_three", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "Already you have 3 minutes to find me!")
chat.PlaySound()
    end)

net.Receive("message_ling_two", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "You have 2 minutes to find me.")
chat.PlaySound()
    end)

net.Receive("message_ling_one", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "You have last 1 minute to find me.")
chat.PlaySound()
    end)

net.Receive("message_ling_boring", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "You are boring.")
chat.PlaySound()
    end)

net.Receive("message_ling_seek3", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "Ready or not, here I come.")
chat.PlaySound()
    end)

net.Receive("message_ling_three2", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "You have 3 minutes to find me.")
chat.PlaySound()
    end)

net.Receive("message_ling_cong2", function(amount)
    local eno = 1
        chat.AddText( Color( 255, 255, 255), "Congratulations.")
chat.PlaySound()
    end)

