AddCSLuaFile()

ENT.Base = "base_nextbot"
ENT.Spawnable = true

function ENT:Initialize()
    self:SetModel("models/nextbott.mdl")
    self:SetSpawnEffect(false)
    self:SetCollisionBounds(Vector(-1, -1, 0), Vector(1, 1, 1))
    self:SetSolid(0)
    self:SetCollisionGroup(10)
    if SERVER then
        self:SetMaxHealth(999999999)
    end
    self:SetHealth(999999999)
    self:SetNWBool("lingerer_happy", true)
    self:SetNWBool("lingerer_boring", false)
    self.acceleration_amount = 250
    self.speed_amount = 1350
    self.LoseTargetDist = 9999999
    self.SearchRadius = 9999999
    self.z_offset = 0
    self.fade_time = 1
    self.fade_dist = 0
    self.fade_timer = 0
    self.col_offset = 255
    self.col_target = 0
    self.wait_time_min = 5
    self.wait_time_max = 5
    self.seeking = false
    self.hiding = false
    self.waiting = false
    self.walking = false
    self.stalking = true
    self.chasing = false
    self.stopchasing = false
    self.lose = 0
    self.chasing_amb_sound_id = 0

    self.warning_sounds = {}
    self.warning_sounds[1] = CreateSound(game.GetWorld(), "teleport_lingerer.wav")

    self.loaded_amb_sounds = {}
    self.loaded_amb_sounds[1] = CreateSound(game.GetWorld(), "chasing_amb_lingerer.wav")
    self.loaded_amb_sounds[2] = CreateSound(game.GetWorld(), "stalk_ambience_1.wav")
    self.loaded_amb_sounds[3] = CreateSound(game.GetWorld(), "stalk_ambience_2.wav")
    self.loaded_amb_sounds[4] = CreateSound(game.GetWorld(), "stalk_ambience_3.wav")
    self.loaded_amb_sounds[5] = CreateSound(game.GetWorld(), "stalk_ambience_4.wav")
    self.loaded_amb_sounds[6] = CreateSound(game.GetWorld(), "stalk_end.wav")
    self.loaded_amb_sounds[7] = CreateSound(self, "chasing_lingerer.wav")
    self.loaded_amb_sounds[8] = CreateSound(self, "chasing_lingerer.wav")

    self.loaded_sounds = {}
    self.loaded_sounds[1] = CreateSound(self, "chasing_lingerer.wav")

    self.stalk_ambience_volume = 1
    self.chase_ambience_volume = 1
    self.self_chase_volume = 0

    self.pre_stalk_timer = 0
    self.stalking_timer = 0
    self.stalking_time = 120
    
    self.last_sound_play = 0
    self.last_chase_amb_sound = 0
    self.last_chase_sound = 0
end

local trace = {
    mask = MASK_SOLID_BRUSHONLY
}

function ENT:SetEnemy(ent)
    self.Enemy = ent
end

function ENT:GetEnemy()
    return self.Enemy
end

function ENT:HaveEnemy()
    if ( self:GetEnemy() and IsValid(self:GetEnemy()) ) then
        if ( self:GetRangeTo(self:GetEnemy():GetPos()) > self.LoseTargetDist ) then
            return self:FindEnemy()
        elseif ( self:GetEnemy():IsPlayer() and !self:GetEnemy():Alive() ) then
            return self:FindEnemy()
        end
        return true
    else
        return self:FindEnemy()
    end
end

function ENT:FindEnemy()
    local _ents = ents.FindInSphere( self:GetPos(), self.SearchRadius )
    for k,v in ipairs( _ents ) do
        if ( v:IsPlayer() ) then
            self:SetEnemy(v)
            return true
        end
    end
    self:SetEnemy(nil)
    return false
end

function ENT:SayAnything(messageid)
    if messageid == 1 then
        net.Start("message_ling_hi")
        net.Broadcast()
    elseif messageid == 2 then
        net.Start("message_ling_bye")
        net.Broadcast()
    elseif messageid == 3 then
        net.Start("message_ling_cong")
        net.Broadcast()
    elseif messageid == 4 then
        net.Start("message_ling_hide")
        net.Broadcast()
    elseif messageid == 5 then
        net.Start("message_ling_seek")
        net.Broadcast()
    elseif messageid == 6 then
        net.Start("message_ling_seek2")
        net.Broadcast()
    elseif messageid == 7 then
        net.Start("message_ling_hideend")
        net.Broadcast()
    elseif messageid == 8 then
        net.Start("message_ling_seekend")
        net.Broadcast()
    elseif messageid == 9 then
        net.Start("message_ling_three")
        net.Broadcast()
    elseif messageid == 10 then
        net.Start("message_ling_two")
        net.Broadcast()
    elseif messageid == 11 then
        net.Start("message_ling_one")
        net.Broadcast()
    elseif messageid == 12 then
        net.Start("message_ling_boring")
        net.Broadcast()
    elseif messageid == 13 then
        net.Start("message_ling_seek3")
        net.Broadcast()
    elseif messageid == 14 then
        net.Start("message_ling_three2")
        net.Broadcast()
    elseif messageid == 15 then
        net.Start("message_ling_cong2")
        net.Broadcast()
    end
end

function ENT:RunBehaviour()
    if (self:HaveEnemy()) then
        self:TeleportToRandom()
        self:SayAnything(1)
    end

    while (true) do
        if (self:HaveEnemy() and !self.waiting) then
            self:StalkEnemy()
        end
        coroutine.wait(2)
    end
end

function ENT:BlindPlayer( pPlayer )
    pPlayer:ScreenFade( SCREENFADE.IN, Color(255, 0, 0, 255), 1, 0.1 )
end

function ENT:InstaGib()
    if (self:VectorDistance(self:GetEnemy():GetPos(), self:GetPos()) < 50 and self:GetEnemy():Alive()) then
	if self.lose >= 5 then
	    self:BlindPlayer(self:GetEnemy())
            self:GetEnemy():SetViewPunchAngles(Angle(200,200*-4,200*4))
            self:GetEnemy():Kill()
            else
            self:TeleportPlayerToRandom()
            end
        self.loaded_amb_sounds[1]:Stop()
	self.stopchasing = true
	self:GoToRandomPoint()
        self.stalking = true
    end
end

function ENT:TeleportPlayerToRandom()
self:GetEnemy():SetViewPunchAngles(Angle(50,50*0,50*5))
            self.warning_sounds[1]:Stop()
            self.warning_sounds[1]:SetSoundLevel(0)
            self.warning_sounds[1]:Play()
    print("Teleported Player")
    local spot_options = {pos = self:GetEnemy():GetPos(), radius = 10000, stepup = 5000, stepdown = 5000}
    local spot = nil
    local lookForSpot = true
    self.path = Path("Chase")
	self.path:SetMinLookAheadDistance(300)
	self.path:SetGoalTolerance(20)
    while (lookForSpot) do
        self.path:Compute(self, self:GetEnemy():GetPos())
        lookForSpot = false
        spot = self:FindSpot('random', spot_options)
        if (spot == nil) then lookForSpot = true end
        if (!self.path:IsValid()) then lookForSpot = true end
        coroutine.wait(0.1)
    end
    
    self:GetEnemy():SetPos(spot)
end

function ENT:VectorDistance(v1, v2)
    return math.sqrt((((v1.x)-(v2.x))*((v1.x)-(v2.x))) + (((v1.y)-(v2.y))*((v1.y)-(v2.y))) + (((v1.z)-(v2.z))*((v1.z)-(v2.z))))
end

function ENT:StalkEnemy( options )
	if self.lose >= 3 then
            self:SetNWBool("lingerer_happy", false)
            self:SetNWBool("lingerer_boring", true)
            else
            self:SetNWBool("lingerer_happy", true)
            self:SetNWBool("lingerer_boring", false)
            end

    self.seeking = false
    self.hiding = false
    self.waiting = true
    self.stalking = true
    self.chasing = false
    self.walking = false

    self.pre_stalk_time = 15
    self.pre_stalk_timer = 0

    self.loco:SetAcceleration(250)
    self.loco:SetDesiredSpeed(1350)

    local options = options or {}
    self.path = Path("Chase")
    self.path:SetMinLookAheadDistance( options.lookahead or 300 )
    self.path:SetGoalTolerance( options.tolerance or 20 )
    self.path:Compute(self, self:GetEnemy():GetPos())

    if ( !self.path:IsValid() ) then
        self.waiting = false
        return "failed"
    end

    self.LastPathRecompute = 0
    self.stalking_timer = 0

    while ( self.path:IsValid() and self:HaveEnemy() and self.stalking) do
        self:InstaGib()
        self.pre_stalk_timer = self.pre_stalk_timer + FrameTime()
        if (!self:GetEnemy():Visible(self)) then
            if (self.pre_stalk_timer > self.pre_stalk_time) then
                if ( self.path:GetAge() > 0.1 ) then
                    self.path:Compute(self, self:GetEnemy():GetPos())
                end
                self.path:Update( self )

                if (CurTime() - self.LastPathRecompute > 0.1) then
                    self.LastPathRecompute = CurTime()
                    self:RecomputeTargetPath(self:GetEnemy():GetPos())
                end

                local stuckTimer = 0
                local stuckTime = 1
                stuckTimer = stuckTimer + FrameTime()

                if (stuckTimer > stuckTime) then
                    self:UnstickFromCeiling()
                    stuckTimer = 0
                end

                self.stalking_timer = self.stalking_timer + FrameTime()
                if (self.stalking_timer > self.stalking_time) then
                    self.stalking_timer = 0
                    self:TeleportToRandom()
                end
            end
        else
            self.stalking = false
            self.waiting = false
            self:PlayRandomGame()
            return "interrupted"
        end

        self:Sounds()

        coroutine.yield()
    end

    self.waiting = false
    return "ok"
end

function ENT:PlayRandomGame()
    if math.random() < 0.5 then
        self:StartHideMode()
    else
        self:StartSeekMode()
    end
end

function ENT:ChasePlayer()
    self:SetNWBool("lingerer_happy", false)
    self:SetNWBool("lingerer_boring", true)

    self.seeking = false
    self.hiding = false
    self.waiting = true
    self.chasing = true
    self.stalking = false
    self.walking = false

    self.stopchasing = false

    self.loco:SetAcceleration(math.random(400,711))
    self.loco:SetDesiredSpeed(2111)

    local options = options or {}
    self.path = Path("Chase")
    self.path:SetMinLookAheadDistance( options.lookahead or 300 )
    self.path:SetGoalTolerance( options.tolerance or 20 )
    self.path:Compute(self, self:GetEnemy():GetPos())

    if ( !self.path:IsValid() ) then
        return "failed"
    end

    local chasing_time = 45
    local chasing_timer = 0

    self.LastPathRecompute = 0

    while (self.path:IsValid() and !self.stopchasing) do
        self:InstaGib()

        chasing_timer = chasing_timer + FrameTime()
        if ( self.path:GetAge() > 0.1 ) then
            self.path:Compute(self, self:GetEnemy():GetPos())
        end
        self.path:Update( self )

        if (CurTime() - self.LastPathRecompute > 0.1) then
            self.LastPathRecompute = CurTime()
            self:RecomputeTargetPath(self:GetEnemy():GetPos())
        end

        if ( options.draw ) then self.path:Draw() end

        local stuckTimer = 0
        local stuckTime = 1
        stuckTimer = stuckTimer + FrameTime()

        if (!self:GetEnemy():Visible(self) and chasing_timer > chasing_time) then
            self.stopchasing = true
        end

        if (stuckTimer > stuckTime) then
            self:UnstickFromCeiling()
            stuckTimer = 0
        end

        self:Sounds()

        coroutine.yield()
    end

    self.chasing = false
    self.waiting = false
    self:GoToRandomPoint()
    self.loaded_amb_sounds[1]:Stop()

    return "ok"
end

function ENT:StartHideMode()
	if self.lose >= 3 then
            self:SetNWBool("lingerer_happy", false)
            self:SetNWBool("lingerer_boring", true)
            else
            self:SetNWBool("lingerer_happy", true)
            self:SetNWBool("lingerer_boring", false)
            end

    self:SayAnything(4)
    self:TeleportToRandom()
    self.hiding = true
    self.seeking = false
    self.waiting = true
    self.stalking = false
    self.chasing = false
    self.walking = false
    local hideStart = CurTime()
    local hideDuration = 240
    local warned60 = false
    local warned120 = false
    local warned180 = false
    while true do
        if IsValid(self:GetEnemy()) then
            local player = self:GetEnemy()
            local playerEyePos = player:EyePos()
            local botPos = self:GetPos()
            local dirToBot = (botPos - playerEyePos):GetNormalized()
            local forward = player:GetAimVector()
            local dot = forward:Dot(dirToBot)
            local distance = playerEyePos:Distance(botPos)
            local fov = 80
            local angleTolerance = math.cos(math.rad(fov / 2))
            local inFOV = dot > angleTolerance
            local traceLine = {}
            traceLine.start = playerEyePos
            traceLine.endpos = botPos
            traceLine.filter = player
            local tr = util.TraceLine(traceLine)
            local visible = inFOV and not tr.Hit and distance < 5000
            if visible then
            		if self.lose >= 3 then
            		self:SayAnything(15)
            		else
            		self:SayAnything(3)
            		end
            if self.lose >= 0 then
            self.lose = self.lose - 1
            else
            end
		self:GoToRandomPoint()
                break
            end
        end
        local elapsed = CurTime() - hideStart
        if not warned60 and elapsed >= 60 then
            if self.lose >= 3 then
            self:SayAnything(14)
            else
            self:SayAnything(9)
            end
            warned60 = true
        end
        if not warned120 and elapsed >= 120 then
            self:SayAnything(10)
            warned120 = true
        end
        if not warned180 and elapsed >= 180 then
            self:SayAnything(11)
            warned180 = true
        end
        if elapsed >= hideDuration then
            if self.lose >= 7 then
            else
            self.lose = self.lose + 1
            end
            if self.lose >= 3 then
            self:SayAnything(12)
            else
            self:SayAnything(7)
            end
            self.hiding = false
            if self.lose >= 3 then
            self:ChasePlayer()
            else
            self:GoToRandomPoint()
            end
            return
        end
        coroutine.yield()
    end
    self.hiding = false
    self.stalking = true
    self.waiting = false
    self.pre_stalk_timer = 0
    self.stalking_timer = 0
end

function ENT:StartSeekMode()
	if self.lose >= 3 then
            self:SetNWBool("lingerer_happy", false)
            self:SetNWBool("lingerer_boring", true)
            else
            self:SetNWBool("lingerer_happy", true)
            self:SetNWBool("lingerer_boring", false)
            end

    self:SayAnything(5)
    self.seeking = true
    self.hiding = false
    self.waiting = true
    self.stalking = false
    self.chasing = false
    self.walking = false
    self.loco:Stop()
    local seekWaitStart = CurTime()
    local seekWaitDuration = 60
    while CurTime() - seekWaitStart < seekWaitDuration do
        self:Sounds()
        coroutine.yield()
    end
            if self.lose >= 3 then
            self:SayAnything(13)
            else
            self:SayAnything(6)
            end
    self.loco:SetAcceleration(250)
    self.loco:SetDesiredSpeed(1350)
    local searchStart = CurTime()
    local searchDuration = 120
    local currentTarget = nil
    local currentPath = nil
    local lastTargetChange = 0
    local targetChangeInterval = 5
    while CurTime() - searchStart < searchDuration do
        if IsValid(self:GetEnemy()) and self:GetEnemy():Visible(self) then
            if self.lose >= 7 then
            else
            self.lose = self.lose + 1
            end
            if self.lose >= 3 then
            self:SayAnything(12)
            else
            self:SayAnything(8)
            end
            if self.lose >= 3 then
            self.seeking = false
            self:ChasePlayer()
            else
            self:GoToRandomPoint()
            end
            return
        end
        if not currentTarget or (CurTime() - lastTargetChange > targetChangeInterval) then
            local spot_options = {pos = self:GetEnemy():GetPos(), radius = 10000, stepup = 5000, stepdown = 5000}
            currentTarget = self:FindSpot('random', spot_options)
            if currentTarget then
                currentPath = Path("Chase")
                currentPath:SetMinLookAheadDistance(300)
                currentPath:SetGoalTolerance(20)
                currentPath:Compute(self, currentTarget)
                lastTargetChange = CurTime()
            end
        end
        if currentPath and currentPath:IsValid() then
            currentPath:Update(self)
            if currentPath:GetAge() > 0.5 then
                currentPath:Compute(self, currentTarget)
            end
        end
        self:Sounds()
        coroutine.yield()
    end
            if self.lose >= 3 then
            self:SayAnything(15)
            else
            self:SayAnything(3)
            end
            if self.lose >= 0 then
            self.lose = self.lose - 1
            else
            end
    GoToRandomPoint()
    self.seeking = false
    self.stalking = true
    self.waiting = false
    self.pre_stalk_timer = 0
    self.stalking_timer = 0
end

function ENT:TeleportToRandom()
    local spot_options = {pos = self:GetEnemy():GetPos(), radius = 10000, stepup = 5000, stepdown = 5000}
    local spot = nil
    local lookForSpot = true
    self.path = Path("Chase")
    self.path:SetMinLookAheadDistance(300)
    self.path:SetGoalTolerance(20)
    while (lookForSpot) do
        self.path:Compute(self, self:GetEnemy():GetPos())
        lookForSpot = false
        spot = self:FindSpot('random', spot_options)
        if (spot == nil) then lookForSpot = true end
        if (!self.path:IsValid()) then lookForSpot = true end
        coroutine.wait(0.1)
    end
    self:SetPos(spot)
    self.waiting = false
    self.walking = false
    self.chasing = false
    self.stalking = false
end

function ENT:GoToRandomPoint()
    self.waiting = true
    self.walking = true
    self.chasing = false
    self.stalking = false

    self.loco:SetAcceleration(278)
    self.loco:SetDesiredSpeed(5625)

    local options = options or {}
    self.path = Path("Chase")
    self.path:SetMinLookAheadDistance( options.lookahead or 500 )
    self.path:SetGoalTolerance( options.tolerance or 10 )
    local spot_options = {pos = self:GetEnemy():GetPos(), radius = 10000, stepup = 5000, stepdown = 5000}
    local spot = self:FindSpot('random', spot_options)

    self.path:Compute(self, spot)

    if ( !self.path:IsValid() ) then
        return "failed"
    end

    local walking_time = 90
    local walking_timer = 0
    self.LastPathRecompute = 0
    local wait_to_tp = 0
    local wait_time = 15

    while ( self.path:IsValid() and self:HaveEnemy() and self.walking) do
        self:InstaGib()

        self.path:Update( self )

        if (CurTime() - self.LastPathRecompute > 0.1) then
            self.LastPathRecompute = CurTime()
            self:RecomputeTargetPath(spot)
        end

        local stuckTimer = 0
        local stuckTime = 1
        stuckTimer = stuckTimer + FrameTime()

        if (stuckTimer > stuckTime) then
            self:UnstickFromCeiling()
            stuckTimer = 0
        end

        walking_timer = walking_timer + FrameTime()
        if (walking_timer > walking_time) then
            walking_timer = 0
            self:TeleportToRandom()
        end

        if (!self:GetEnemy():Visible(self)) then
            wait_to_tp = wait_to_tp + FrameTime()
            if (wait_to_tp > wait_time) then
                self:TeleportToRandom()
            end
        end

        self:Sounds()

        coroutine.yield()
    end

    self.walking = false
    self.waiting = false

    return "ok"
end

local VECTOR_HIGH = Vector(0, 0, 16384)
ENT.LastPathingInfraction = 0

function ENT:RecomputeTargetPath(path_target)
    if (CurTime() - self.LastPathingInfraction < 5) then
        return
    end

    local targetPos = path_target

    trace.start = targetPos
    trace.endpos = targetPos - VECTOR_HIGH
    trace.filter = self:GetEnemy()
    local tr = util.TraceEntity(trace, self:GetEnemy())

    if (tr.Hit and util.IsInWorld(tr.HitPos)) then
        targetPos = tr.HitPos
    end

    local rTime = SysTime()
    self.path:Compute(self, targetPos)

    if (SysTime() - rTime > 0.005) then
        self.LastPathingInfraction = CurTime()
    end
end

function ENT:UnstickFromCeiling()
    if (self:IsOnGround()) then return end

    local myPos = self:GetPos()
    local myHullMin, myHullMax = self:GetCollisionBounds()
    local myHull = (myHullMax - myHullMin)
    local myHullTop = myPos + vector_up * myHull.z
    trace.start = myPos
    trace.endpos = myHullTop
    trace.filter = self
    local upTrace = util.TraceLine(trace, self)

    if (upTrace.Hit and upTrace.HitNormal ~= vector_origin and upTrace.Fraction > 0.5) then
        local unstuckPos = myPos + upTrace.HitNormal * (myHull.z * (1 - upTrace.Fraction))
        self:SetPos(unstuckPos)
    end
end

function ENT:Sounds()
    if self.seeking or self.stalking then
        if CurTime() - self.last_sound_play > 0.025 then
            self.loaded_amb_sounds[7]:Stop()
            self.loaded_amb_sounds[7]:SetSoundLevel(70)
            self.loaded_amb_sounds[7]:Play()
            self.last_sound_play = CurTime()
        end
    end

    if self.chasing then
        if CurTime() - self.last_chase_amb_sound > 17.48 then
            self.loaded_amb_sounds[1]:Stop()
            self.loaded_amb_sounds[1]:SetSoundLevel(0)
            self.loaded_amb_sounds[1]:Play()
            self.last_chase_amb_sound = CurTime()
        end
        if CurTime() - self.last_chase_sound > 1.35 then
            self.loaded_sounds[1]:Stop()
            self.loaded_sounds[1]:SetSoundLevel(70)
            self.loaded_sounds[1]:Play()
            self.last_chase_sound = CurTime()
        end
    end
end

function ENT:OnRemove()
	if self.lose >= 3 then
            else
            self:SayAnything(2)
            end
    for k, v in pairs(self.loaded_amb_sounds) do
        v:Stop()
    end
    for k, v in pairs(self.loaded_sounds) do
        v:Stop()
    end
end

ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
local lingererMaterial = Material("entities/rn_flingerer.png", "smooth mips")
local lingerer2Material = Material("boring.png", "smooth mips")
local draw_offset = Vector(0, 0, 64)

function ENT:RenderOverride()
    self:SetRenderBounds(Vector(-80, -80, 0), Vector(80, 80, 80))
    local lingererMat1 = self:GetNWBool("lingerer_happy")
    local lingererMat2 = self:GetNWBool("lingerer_boring")
    if (!lingererMat1) and (!lingererMat2) then
        render.SetMaterial(lingererMaterial)
    elseif (lingererMat1) then
        render.SetMaterial(lingererMaterial)
    elseif (lingererMat2) then
        render.SetMaterial(lingerer2Material)
    end
	render.DrawSprite(self:GetPos() + draw_offset, 128, 128)
end

list.Set("NPC", "rn_flingerer", {
    Name = "Friendly Lingerer",
    Class = "rn_flingerer",
    Category = "RipPersik's Nextbots"
})