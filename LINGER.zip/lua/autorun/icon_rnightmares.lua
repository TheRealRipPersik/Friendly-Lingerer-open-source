if (SERVER) then return end

local path = "rnightmares.png"

hook.Add("PopulateNPCs", "RNightmares", function(pnlContent, tree, browseNode)
    for _, node in pairs(tree:Root():GetChildNodes()) do
        if (node:GetText() == "RipPersik's NIGHTMARES") then
            node.Icon:SetImage(path)
        end
    end
end)